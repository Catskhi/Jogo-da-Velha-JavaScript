var but = document.querySelector('div#but')
let bot = ''
var escolha = ''
let patual = document.querySelector('p#Atual')
var b1 = document.querySelector('div#box1')
var b2 = document.querySelector('div#box2')
var b3 = document.querySelector('div#box3')
var b4 = document.querySelector('div#box4')
var b5 = document.querySelector('div#box5')
var b6 = document.querySelector('div#box6')
var b7 = document.querySelector('div#box7')
var b8 = document.querySelector('div#box8')
var b9 = document.querySelector('div#box9')

let bs = [] 

function Select(choice) {
    but.outerHTML = ''
    escolha = choice
    let jog = Math.floor(Math.random() * 2) + 1

    if(jog == 1) {
        if(escolha == 'O') {
            patual.innerHTML = 'O Jogador começa com O!'
            bot = 'X'
            Main('Jogador')
        } else {
            patual.innerHTML = 'O Jogador começa com X!'
            bot = 'O'
            Main('Jogador')
        }
        
    } else {
        if(escolha == 'O') {
            patual.innerHTML = 'O bot começa com X!'
            bot = 'X'
            Main('Bot')
        } else {
            patual.innerHTML = 'O bot começa com O!'
            bot = 'O'
            Main('Bot')
        }
    }
}
var attual = ''
let vencedor = ''
function Main(começa) {
    let com = começa;
    if(com == 'Jogador') {
        Vence('Jogador')
    } else {
        Vence('Bot')
    }
} 

function Vence(atual) {
    attual = atual
    Seramsm(vencedor)
    if (vencedor == '') {
        if(atual == 'Jogador') {
            patual.innerHTML = 'Turno do Jogador!'
        } else if (atual == 'Bot'){
            patual.innerHTML = 'Turno do Bot!'
            Bot()
        }
    } else if (vencedor == 'Jogador') {
        patual.innerHTML = 'O Jogador venceu!!'
    } else if (vencedor == 'Bot') {
        patual.innerHTML = 'O Bot venceu!'
    } else {
        patual.innerHTML = 'Deu Velha!'
    }
}

function Seramsm() {
    if(bs[0] == 'J' && bs[1] == 'J' && bs[2] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[0] == 'J' && bs[3] == 'J' && bs[6] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[0] == 'J' && bs[4] == 'J' && bs[8] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[1] == 'J' && bs[4] == 'J' && bs[7] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[2] == 'J' && bs[4] == 'J' && bs[6] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[3] == 'J' && bs[4] == 'J' && bs[5] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[2] == 'J' && bs[5] == 'J' && bs[8] == 'J') {
        vencedor = 'Jogador'
    } else if (bs[6] == 'J' && bs[7] == 'J' && bs[8] == 'J') {
        vencedor = 'Jogador'
    }
    //Verifica se o bot foi o vencedor
    else if(bs[0] == 'B' && bs[1] == 'B' && bs[2] == 'B') {
        vencedor = 'Bot'
    } else if (bs[0] == 'B' && bs[3] == 'B' && bs[6] == 'B') {
        vencedor = 'Bot'
    } else if (bs[0] == 'B' && bs[4] == 'B' && bs[8] == 'B') {
        vencedor = 'Bot'
    } else if (bs[1] == 'B' && bs[4] == 'B' && bs[7] == 'B') {
        vencedor = 'Bot'
    } else if (bs[2] == 'B' && bs[4] == 'B' && bs[6] == 'B') {
        vencedor = 'Bot'
    } else if (bs[3] == 'B' && bs[4] == 'B' && bs[5] == 'B') {
        vencedor = 'Bot'
    } else if (bs[2] == 'B' && bs[5] == 'B' && bs[8] == 'B') {
        vencedor = 'Bot'
    } else if (bs[6] == 'B' && bs[7] == 'B' && bs[8] == 'B') {
        vencedor = 'Bot'
    } 
}

function Acao(num) {
    if(attual == 'Jogador') {
        switch (num) {
            case 1:
                if(b1.innerHTML == '.') {
                    b1.innerHTML = `${escolha}`
                    bs[0] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 2:
                if(b2.innerHTML == '.') {
                    b2.innerHTML = `${escolha}`
                    bs[1] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 3:
                if(b3.innerHTML == '.') {
                    b3.innerHTML = `${escolha}`
                    bs[2] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 4:
                if(b4.innerHTML == '.') {
                    b4.innerHTML = `${escolha}`
                    bs[3] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 5:
                if(b5.innerHTML == '.') {
                    b5.innerHTML = `${escolha}`
                    bs[4] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 6:
                if(b6.innerHTML == '.') {
                    b6.innerHTML = `${escolha}`
                    bs[5] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 7:
                if(b7.innerHTML == '.') {
                    b7.innerHTML = `${escolha}`
                    bs[6] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 8:
                if(b8.innerHTML == '.') {
                    b8.innerHTML = `${escolha}`
                    bs[7] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;

            case 9:
                if(b9.innerHTML == '.') {
                    b9.innerHTML = `${escolha}`
                    bs[8] = 'J'
                    Vence('Bot')
                } else {
                    alert('Marque um quadrado vazio!')
                    Vence('Jogador')
                }
                break;
        }
    }
}

function Bot() {
    var escolhabot = Math.floor(Math.random() * 9) + 1
    switch (escolhabot) {
        case 1:
            if(b1.innerHTML == '.') {
                b1.innerHTML = `${bot}`
                bs[0] = 'B'
            } else {
                Bot()
            }
            break;

        case 2: 
            if(b2.innerHTML == '.') {
                b2.innerHTML = `${bot}`
                bs[1] = 'B'
            } else {
                Bot()
            }
            break;

        case 3:
            if(b3.innerHTML == '.') {
                b3.innerHTML = `${bot}`
                bs[2] = 'B'
            } else {
                Bot()
            }
            break;

        case 4:
            if(b4.innerHTML == '.') {
                b4.innerHTML = `${bot}`
                bs[3] = 'B'
            } else [
                Bot()
            ]
            break;

        case 5:
            if(b5.innerHTML == '.') {
                b5.innerHTML = `${bot}`
                bs[4] = 'B'
            } else {
                Bot()
            }
            break;

        case 6:
            if(b6.innerHTML == '.') {
                b6.innerHTML = `${bot}`
                bs[5] = 'B'
            } else {
                Bot()
            }
            break;

        case 7:
            if(b7.innerHTML == '.') {
                b7.innerHTML = `${bot}`
                bs[6] = 'B'
            } else {
                Bot()
            }
            break;

        case 8:
            if(b8.innerHTML == '.') {
                b8.innerHTML = `${bot}`
                bs[7] = 'B'
            } else {
                Bot()
            }
            break;

        case 9:
            if(b9.innerHTML == '.') {
               b9.innerHTML = `${bot}` 
               bs[8] = 'B'
            } else {
                Bot()
            }
            break;
    }
    Vence('Jogador')
}

function recomeça() {
    location.reload();
    return false;
}